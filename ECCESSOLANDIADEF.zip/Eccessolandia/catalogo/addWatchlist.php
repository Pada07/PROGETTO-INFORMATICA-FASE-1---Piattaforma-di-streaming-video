<?php
// aggiungo il contenuto alla watchlist dell'account attivo
session_start();
if (!isset($_SESSION['id_account_attivo'])) {
    header("Location: ../auth/scegli_account.php");
    exit();
}
require_once '../config/db.php';
if (!isset($_GET['id'])) { die("Nessun contenuto selezionato."); }
$id_contenuto = $_GET['id'];
$id_account = $_SESSION['id_account_attivo'];
// aggiorno il campo isWatchlist del contenuto a '1' per l'account attivo
$query = "UPDATE CONTENUTO SET isWatchlist = '1' WHERE ID_Contenuto = $id_contenuto";
try {
    if ($connessione->query($query) === TRUE) {
        header("Location: watchlist.php");
        exit();
    } else {
        header("Location: dettaglio.php?id=$id_contenuto&errore_watchlist=1");
        exit();
    }
} catch (mysqli_sql_exception $e) {
    header("Location: dettaglio.php?id=$id_contenuto&errore_watchlist=1");
    exit();
}
?>